import React, { useState, useEffect } from "react";
import axios from "axios";

const API_URL = "https://YOUR_BACKEND_URL"; // replace with FastAPI URL

function App() {
  const [name, setName] = useState("");
  const [leaderboard, setLeaderboard] = useState([]);

  const logAction = async (action) => {
    await axios.post(`${API_URL}/log`, { name, action });
    fetchLeaderboard();
  };

  const fetchLeaderboard = async () => {
    const res = await axios.get(`${API_URL}/leaderboard`);
    setLeaderboard(res.data);
  };

  useEffect(() => { fetchLeaderboard(); }, []);

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>HealthQuest Global</h1>
      <input
        placeholder="Your Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        style={{ padding: "0.5rem", marginRight: "1rem" }}
      />
      <button onClick={() => logAction("bp_check")}>Log Blood Pressure</button>
      <button onClick={() => logAction("nutrition_log")}>Log Nutrition</button>

      <h2>Leaderboard</h2>
      <ul>
        {leaderboard.map((u, i) => (
          <li key={i}>
            {u.name}: {u.points} pts (Level {u.level})
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
