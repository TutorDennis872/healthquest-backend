from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import sqlite3

app = FastAPI()

# Allow frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set to your domain for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database setup
conn = sqlite3.connect('health_game.db', check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    points INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1,
    streak INTEGER DEFAULT 0
)''')
conn.commit()

class HealthLog(BaseModel):
    name: str
    action: str  # "bp_check" or "nutrition_log"

@app.post("/log")
def log_health(data: HealthLog):
    user_name = data.name.strip().lower()
    c.execute("SELECT id, points, level, streak FROM users WHERE name=?", (user_name,))
    user = c.fetchone()

    if not user:
        c.execute("INSERT INTO users (name) VALUES (?)", (user_name,))
        conn.commit()
        user_id, points, level, streak = c.lastrowid, 0, 1, 0
    else:
        user_id, points, level, streak = user

    points_earned = 20 if data.action == "bp_check" else 15
    streak += 1
    points += points_earned + (10 if streak % 7 == 0 else 0)

    if points >= level * 200:
        level += 1

    c.execute(
        "UPDATE users SET points=?, level=?, streak=? WHERE id=?",
        (points, level, streak, user_id)
    )
    conn.commit()

    return {
        "user": user_name,
        "points": points,
        "level": level,
        "streak": streak
    }

@app.get("/leaderboard")
def leaderboard():
    c.execute("SELECT name, points, level FROM users ORDER BY points DESC LIMIT 10")
    rows = c.fetchall()
    return [{"name": r[0], "points": r[1], "level": r[2]} for r in rows]
